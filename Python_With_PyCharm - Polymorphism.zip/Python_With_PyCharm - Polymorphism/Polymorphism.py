class car:
    def __init__(self, color, type):
        self.color = color
        self.type = type
        self.make = "Default"
        self.model = "Default"

    def printcarinfo(self):
        print("Make:",self.make, "\nModel:", self.model, "\nColor:", self.color, "\nType:", self.type)

class Ford(car):
    def __init__(self, model, color, type):
        car.__init__(self, color, type)
        self.make = "Ford"
        self.model = model

class Generic(car):
        pass



print("GENERIC CAR")
cars = car("Brown", "Sedan")
cars.printcarinfo()

print('\n')

print("FORD")
Fordcars = Ford("F150", "Blue", "Pickup Truck")
Fordcars.printcarinfo()

print('\n')

print("ANOTHER GENERIC CAR")
genericcar = Generic("White", "Hybrid")
genericcar.printcarinfo()