#Array

#Have you want to put in mutliple values in one variable?

#How to Implement Array
import random

dice = [1, 2, 3, 4, 5, 6]

for i in range (0, 6):
    print (dice[i])

#Practical Application

loop = True
dice_input = int(input("Enter Your Dice Number Guess!! "))
while loop:
    rdicenum = random.randint(0, 5)
    print(dice[rdicenum])
    if (dice_input == -1):
        loop = False
        print("Exiting the game!! Hope you had a good time!!")
        break
    if (dice_input == dice[rdicenum]):
        print("You guess it right!!")
        dice_input = int(input("Enter Your Dice Number Guess!! "))
    elif (dice_input != dice[rdicenum]):
        print("You guessed wrong!!")
        dice_input = int(input("Enter Your Dice Number Guess!! "))
