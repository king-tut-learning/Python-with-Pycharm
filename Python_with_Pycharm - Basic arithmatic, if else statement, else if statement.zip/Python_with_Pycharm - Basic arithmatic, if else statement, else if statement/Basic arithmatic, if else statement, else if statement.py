#Comments are texts you type in but does not get executed
#good for annotating a line or a block of code
#also good when you are doing tutorial =)

#how to comment
#This is a comment

#your computer can do basic arithmatic
#Symbols for basic arithmatic
# + -- Addition
print ("Addition: ")
print (2+2)
# - -- Subtraction
print ("Subtraction: ")
print (2-2)
# * -- Multiplication
print ("Multiplication: ")
print (2*2)
# / -- Division
print ("Division: ")
print (2/2)
# % -- Modulo (division but only gives remainder as result)
print ("Modulo: ")
print (2%2)
# ** -- Exponent
print ("Exponent: ")
print (2**2)

#Practical Example:
x = input("Enter First Number: ")
y = input("Enter Second Number: ")

result = int(x) + int(y)

print("Result: ")
print(result)

#Conditional statement is when code gets executed as a result of a
#condition
#You use the if/else statement
#Else statement is when no conditions from the if statement is true
#a certian block of code executes inside the else statement
#Else statement is optional and must have an if statement

#How to write an if statement
print("If/Else Statement: ")
x = input("Enter First Number: ")
y = input("Enter Second Number: ")
Option = input("Select Operation (1)+ (Any key)-")

if (Option == "1"):
    result = int(x) + int(y)
else:
    result = int(x) - int(y)

print("Result: ")
print(result)

#if you have more than one condition and want the rest of the condition to be
#skipped over if one of the condition is true, you use an elif statement

#how to write an elif statement
print("If/Else Statement: ")
x = input("Enter First Number: ")
y = input("Enter Second Number: ")
Option = input("Select Operation (1)+ (2)- (3)* (4)/")

if (Option == "1"):
    result = int(x) + int(y)
elif (Option == "2"):
    result = int(x) - int(y)
elif (Option == "3"):
    result = int(x) * int(y)
elif (Option == "4"):
    result = float(x) / float(y)


print("Result: ")
print(result)