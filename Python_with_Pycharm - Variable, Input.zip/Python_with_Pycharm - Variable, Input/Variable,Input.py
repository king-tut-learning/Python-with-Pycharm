#In a variable you can assign it to anything
a = input ("Enter first number: ")
#To allow input you need to put in the input function and inside
#the paranthesis, you can put in text that you print out
b = input ("Enter second number: ")


#you add two result and be sure to cast an int for whole number
#or a float for numbers with decimals
result = float(a) + float(b)

#print out the result
print(result)