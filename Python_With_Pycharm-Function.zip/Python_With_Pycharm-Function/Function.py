
#Function without an argument
def printstuff():
    print("King Tut Rocks")

printstuff()

#function with an argument
def printstuffarg(word):
    print(word)

printstuffarg("King Tut Rules!!")

#function used like a variable
def returnprintstuff(word):
    return word

print(returnprintstuff("King Tut Returns!!"))