#Self

#referring to a variable or any data holder in that class
class kingtut:
    def __init__(self):
        self.ValleyofKings = "King Tut is buried here!!"
    def printout(self):
        print(self.ValleyofKings)


x = kingtut()
x.printout()