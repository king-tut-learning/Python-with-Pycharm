#Class

#Grouping Functions and Variables into one group

#How to implement a class
class kingtut:
    def __init__(self):
        self.ValleyofKings = "King Tut is buried here!!"
    def printout(self):
        print(self.ValleyofKings)


x = kingtut()
x.printout()