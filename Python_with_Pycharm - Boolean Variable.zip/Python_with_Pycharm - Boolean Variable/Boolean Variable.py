#Boolean Variable
#A Boolean Variable is a kind of variable that takes the value of True and False

#Example of boolean variable
var = False

print(int(var))

#Practical Application
isright = False

answer = input("2 + 2 = ")
if answer == "4":
    isright = True

print(isright * "Correct!!")

if not isright:
    print("Wrong!!")