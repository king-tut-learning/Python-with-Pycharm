#For loop
#A limited amount of loop or iteration of the block of code

#How to implement For Loop?
for x in range(0,10, 1):
    print (x)

#Practical Example
print("Starting Orbital Launch Countdown...")
for x in range(5, 0, -1):
    print (x)
print("Liftoff!!")