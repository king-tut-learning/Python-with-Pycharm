#While Loop
#A conditional loop aka a kind of loop that
#keeps looping until the condition is false

#How to implement the while loop
x = 0

while x < 7:
    print("Hello ", x)
    x = x + 1

#Practical Application
y = 2
number = int(input("Enter A Number: "))
while number != y:
    if (number != y):
        number = int(input("Incorrect!! Enter A Number: "))

print("Correct!!")