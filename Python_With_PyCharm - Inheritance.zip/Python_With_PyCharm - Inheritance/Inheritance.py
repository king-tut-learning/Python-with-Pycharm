class richguy():
    def __init__(self):
        self.firstname = "Donald"
        self.lastname = "Trump"
        self.worth = 1000000000
    def printworth(self):
        print(self.firstname, self.lastname, "has $", self.worth)

class richguyson(richguy):
    def __init__(self):
        richguy.__init__(self)

    def printinheritance(self):
        print(self.firstname, self.lastname, "jr. has $", self.worth/2)




rich = richguy()
rich.printworth()

richjr = richguyson()
richjr.printinheritance()